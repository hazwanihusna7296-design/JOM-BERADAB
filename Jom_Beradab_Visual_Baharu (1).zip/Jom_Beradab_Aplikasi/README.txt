JOM BERADAB — Aplikasi Gamifikasi Pendidikan Islam Tingkatan 2

CARA MENJALANKAN
1. Ekstrak fail ZIP.
2. Untuk permainan asas, buka index.html menggunakan pelayar moden.
3. Untuk kamera/pengesanan tangan, lebih baik jalankan melalui localhost atau HTTPS:
   - Jika Python dipasang, buka terminal dalam folder ini dan jalankan:
       python -m http.server 8000
   - Buka http://localhost:8000
4. Tekan “Hidupkan kamera” dan benarkan akses kamera apabila diminta.
5. Pengecaman tangan menggunakan MediaPipe Tasks Vision melalui CDN, jadi sambungan internet diperlukan untuk memuat turun pustaka dan model. Jika ia gagal dimuatkan, permainan gestur masih mempunyai kawalan butang.

REKOD
- Rekod disimpan dalam localStorage pelayar/peranti ini sahaja.
- Gunakan “Eksport CSV” untuk menyimpan salinan.
- Tiada penghantaran automatik ke Google Sheets/pangkalan data berpusat.

NOTA PENGUJIAN
- Struktur HTML/JS dan sintaks asas disediakan; fail belum diuji secara automatik dalam semua pelayar/peranti.
- Sila uji kamera, izin kamera, pengesanan tangan dan fungsi butang pada peranti sebenar.
- Pengecaman gestur adalah prototaip asas: tidak semua sembilan gestur dapat dikesan secara semantik dengan ketepatan penuh. Aktiviti gestur menyediakan alternatif butang; sesuaikan dan uji sebelum penggunaan PdP sebenar.
